# Drafting-task image assets for Asiamiestutkinto-trainer

These PNG files are exact page renders from the PRH patent-exam PDFs already used as sources for the repository dataset. They are intended to be uploaded under a stable repository path such as:

`exam_data/assets/drafting/`

## Included assets

### 2020 - patent-2020-section-1
- `patent-2020-section-1-page-01.png`
- The technical drawings are embedded in the task's first page, together with task text. This is deliberately kept as a full-page render so no drawing detail is accidentally cropped.

### 2021 - patent-2021-section-1
- `patent-2021-section-1-page-03.png`
- `patent-2021-section-1-page-04.png`
- `patent-2021-section-1-page-05.png`
- `patent-2021-section-1-page-06.png`
- These pages contain the drawing set for the blind-bolt drafting task.

### 2022 - patent-2022-section-1
- `patent-2022-section-1-page-04.png`
- `patent-2022-section-1-page-05.png`
- These pages contain the drawing set for the piano-tone-adjustment drafting task.

### 2023 - patent-2023-section-1
- `patent-2023-section-1-page-05.png`
- `patent-2023-section-1-page-06.png`
- `patent-2023-section-1-page-07.png`
- `patent-2023-section-1-page-08.png`
- These pages contain Figures 1-7 for the skate-sharpener drafting task.

## 2024

The published 2024 PRH model-answer PDF refers to Figures 1-3 in the pumpkin-press task, but the published PDF pages themselves do not visibly contain those figures and I did not find a separate official figure PDF on the 2024 PRH exam page. Do not fabricate replacement drawings. If an original 2024 figure source is later located, add it as a source-backed asset.

## 2025

PRH publishes the 2025 drafting-task figures separately as a two-page PDF named `Pat2025_kuvat.pdf` ("Patenttioikeus, tehtävä 1 kuvat"). Download that official PDF from the PRH 2025 exam page and either keep it as a source asset or render its two pages to PNGs before integration.

Official figure PDF URL:
https://www.prh.fi/material/sites/prh/attachments/tietoaprhsta/teollisoikeusasiamieslautakunta/asiamiestutkinto/flha6s9kt/Pat2025_kuvat.pdf

## Integration note

Do not implement image support by appending these images into `question_text`. Prefer a separate item field such as `assets` containing repository-relative paths and captions. The Colab UI can render those assets immediately after the question text and before the answer box.
